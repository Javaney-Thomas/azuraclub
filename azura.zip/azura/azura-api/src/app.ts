import express from "express";
import http from "http";
import cors from "cors";
import bodyParser from "body-parser";
import { ApolloServer } from "@apollo/server";
import { expressMiddleware } from "@apollo/server/express4";
import { ApolloServerPluginDrainHttpServer } from "@apollo/server/plugin/drainHttpServer";
import { mergeTypeDefs, mergeResolvers } from "@graphql-tools/merge";
import { gql } from "graphql-tag";
import { GraphQLUpload, graphqlUploadExpress } from "graphql-upload-ts";

import authSchema from "./schemas/auth.schema";
import productSchema from "./schemas/product.schema";
import cartSchema from "./schemas/cart.schema";
import orderSchema from "./schemas/order.schema";
import analyticsSchema from "./schemas/analytics.schema";
import userSchema from "./schemas/user.schema";
import contentSchema from "./schemas/content.schema";
import adminSchema from "./schemas/admin.schema";
import reviewSchema from "./schemas/review.schema";

import authResolvers from "./resolvers/auth.resolver";
import productResolvers from "./resolvers/product.resolver";
import cartResolvers from "./resolvers/cart.resolver";
import orderResolvers from "./resolvers/order.resolver";
import analyticsResolvers from "./resolvers/analytics.resolver";
import userResolvers from "./resolvers/user.resolver";
import contentResolvers from "./resolvers/content.resolver";
import adminResolvers from "./resolvers/admin.resolver";

// import authMiddleware from "./middlewares/auth.middleware";
// import error from "./middlewares/error.middleware";
// import loggerMiddleware from "./middlewares/logger.middleware";
// import rateLimiter from "./middlewares/rateLimiter.middleware";

import { verifyToken } from "./utils/jwt.util";
import reviewResolvers from "./resolvers/review.resolver";

// Base type definitions including custom scalars.
const baseTypeDefs = gql`
  scalar Upload
  scalar JSON

  type Query {
    _empty: String
  }

  type Mutation {
    _empty: String
  }
`;

// Merge all type definitions.
const typeDefs = mergeTypeDefs([
  baseTypeDefs,
  authSchema,
  productSchema,
  cartSchema,
  orderSchema,
  analyticsSchema,
  userSchema,
  contentSchema,
  adminSchema,
  reviewSchema,
]);

// Merge all resolvers.
const resolvers = mergeResolvers([
  {
    Upload: GraphQLUpload,
  },
  authResolvers,
  productResolvers,
  cartResolvers,
  orderResolvers,
  analyticsResolvers,
  userResolvers,
  contentResolvers,
  adminResolvers,
  reviewResolvers,
]);

// Create an Express application.
const app = express();

// Create an HTTP server.
const httpServer = http.createServer(app);

// Initialize Apollo Server.
const server = new ApolloServer({
  typeDefs,
  resolvers,
  csrfPrevention: false,
  plugins: [ApolloServerPluginDrainHttpServer({ httpServer })],
  allowBatchedHttpRequests: true,
  status400ForVariableCoercionErrors: true,
});

// Function to start the Apollo Server and apply middleware.
export const startApolloServer = async () => {
  await server.start();

  app.use(
    "/graphql",
    cors(),
    graphqlUploadExpress({ maxFileSize: 10000000, maxFiles: 10 }),
    bodyParser.json(),
    expressMiddleware(server, {
      context: async ({ req }) => {
        const token = req.headers.authorization
          ? req.headers.authorization.split(" ")[1]
          : "";
        let user = null;
        if (token) {
          try {
            user = verifyToken(token);
          } catch (error) {
            console.error("Invalid token:", error);
          }
        }
        return { user };
      },
    })
  );

  return httpServer;
};

export default app;
