# Azura Project

Azura is a full-stack marketplace application that is divided into two main parts:

- **azura-api**: The backend API built with Node.js, Express, GraphQL, MongoDB, and Mongoose.
- **azura-client**: The frontend built with Next.js, React, Apollo Client, and Tailwind CSS.

## Project Structure

```
azura/
│── azura-api/    # Backend API
│── azura-client/ # Frontend Application
│── README.md
```

## Setup Instructions

### Prerequisites

Ensure you have the following installed on your system:

- Node.js (v18+)
- MongoDB
- npm or yarn

### Backend Setup (azura-api)

1. Navigate to the backend directory:

   ```sh
   cd azura-api
   ```

2. Install dependencies:

   ```sh
   npm install
   ```

3. Create an `.env` file with the following variables:

   ```env
   MONGO_URI=mongodb://localhost:27017/azura
   PORT=4000
   JWT_SECRET=your_jwt_secret
   CLOUDINARY_CLOUD_NAME=your_cloudinary_name
   CLOUDINARY_API_KEY=your_cloudinary_api_key
   CLOUDINARY_API_SECRET=your_cloudinary_api_secret
   STRIPE_SECRET_KEY=your_stripe_secret_key
   ```

4. Start the MongoDB server if it's not already running:

   ```sh
   mongod
   ```

5. Start the backend server:
   ```sh
   npm run dev
   ```

### Frontend Setup (azura-client)

1. Navigate to the frontend directory:

   ```sh
   cd azura-client
   ```

2. Install dependencies:

   ```sh
   npm install
   ```

3. Create an `.env.local` file with the following variables:

   ```env
   NEXT_PUBLIC_API_URL=http://localhost:4000/graphql
   NEXT_PUBLIC_STRIPE_PUBLIC_KEY=your_stripe_public_key
   ```

4. Start the frontend development server:
   ```sh
   npm run dev
   ```

## Database Seeding (Dummy Data)

A `data.json` file is available for populating the MongoDB database with dummy data.

1. Ensure MongoDB is running.
2. Import the JSON file using:
   ```sh
   mongoimport --db azura --collection products --file data.json --jsonArray
   ```

## Running Tests

### Backend Tests

Run tests using Jest:

```sh
cd azura-api
npm run test
```

### Frontend Tests

Run tests using Jest and React Testing Library:

```sh
cd azura-client
npm run test
```

## API Documentation

Once the backend is running, access the GraphQL API via Apollo Studio:

```
http://localhost:4000/graphql
```

## Deployment

### Backend Deployment

1. Build the backend:
   ```sh
   npm run build
   ```
2. Deploy on services like Heroku, Vercel, or AWS.

### Frontend Deployment

1. Build the frontend:
   ```sh
   npm run build
   ```
2. Deploy on Vercel, Netlify, or any static hosting provider.

## Contribution

To contribute:

- Fork the repository
- Create a new branch
- Commit your changes
- Open a pull request

## License

This project is licensed under the MIT License.
