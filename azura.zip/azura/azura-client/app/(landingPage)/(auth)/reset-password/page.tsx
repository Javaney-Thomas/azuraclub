import React from "react";
import ResetPassword from ".";

const page = () => {
  return <ResetPassword />;
};

export default page;
