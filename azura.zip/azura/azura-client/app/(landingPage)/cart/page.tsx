import React from "react";
import Cart from ".";

const page = () => {
  return <Cart />;
};

export default page;
