import React from "react";
import CheckoutPage from ".";

const page = () => {
  return <CheckoutPage />;
};

export default page;
