"use client";

import React, { useState } from "react";
import Link from "next/link";
import { useRouter } from "next/navigation";
import { useMutation, useQuery } from "@apollo/client";
import {
  Elements,
  CardElement,
  useStripe,
  useElements,
} from "@stripe/react-stripe-js";
import { loadStripe } from "@stripe/stripe-js";
import { toast } from "sonner";
import client from "@/app/lib/apollo-client";

import { CREATE_ORDER, GET_CART } from "@/app/shared/utils/queries";
import { CartItem } from "../shared/type";
import { Button } from "@/components/ui/button";
import { ImgComp } from "@/app/shared/ImgComp";

// Load your publishable Stripe key
const stripePromise = loadStripe(
  process.env.NEXT_PUBLIC_STRIPE_PUBLISHABLE_KEY!
);

interface CheckoutFormProps {
  cartItems: CartItem[];
}

// Utility function to compute total
function computeTotal(cartItems: CartItem[]) {
  return cartItems.reduce((acc, item) => {
    const price = item.product.price ?? 0; // ensure price is valid
    return acc + price * item.quantity;
  }, 0);
}

// The Payment Form (right column)
const CheckoutForm: React.FC<CheckoutFormProps> = ({ cartItems }) => {
  const stripe = useStripe();
  const elements = useElements();
  const router = useRouter();
  const [createOrder, { loading }] = useMutation(CREATE_ORDER);
  const [errorMsg, setErrorMsg] = useState<string | null>(null);

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!stripe || !elements) return;

    // Transform cartItems into the format needed by your backend
    const formattedCartItems = cartItems.map((item) => ({
      productId: item.product.id,
      quantity: item.quantity,
    }));

    try {
      const { data } = await createOrder({
        variables: { cartItems: formattedCartItems, paymentMethod: "card" },
      });

      const clientSecret: string = data.createOrder.clientSecret;

      const result = await stripe.confirmCardPayment(clientSecret, {
        payment_method: { card: elements.getElement(CardElement)! },
      });

      if (result.error) {
        setErrorMsg(result.error.message || "Payment failed");
        toast.error(result.error.message || "Payment failed");
      } else if (result.paymentIntent?.status === "succeeded") {
        toast.success("Payment successful!");
        // Clear Apollo cache
        client.resetStore();
        // Redirect to order success page
        router.push("/order-success");
      }
    } catch (err) {
      console.error(err);
      setErrorMsg("An unexpected error occurred");
      toast.error("An unexpected error occurred");
    }
  };

  return (
    <form
      onSubmit={handleSubmit}
      className="space-y-4 rounded-md border border-gray-200 p-4 shadow-sm"
    >
      <h2 className="mb-2 text-lg font-semibold text-gray-800">Payment</h2>
      <CardElement className="rounded-md border p-4" />
      {errorMsg && <p className="text-sm text-red-500">{errorMsg}</p>}

      {cartItems.length < 1 ? (
        <div className="flex flex-col items-center space-y-4 pt-2">
          <p className="text-sm text-gray-600">Your cart is empty.</p>
          <Link href="/products">
            <Button className="w-full bg-blue-600 hover:bg-blue-700 text-white py-2 px-4 rounded-md">
              Explore Products
            </Button>
          </Link>
        </div>
      ) : (
        <button
          type="submit"
          disabled={!stripe || loading}
          className="mt-4 w-full rounded-md bg-primaryx py-2 px-4 text-sm font-medium text-white hover:bg-primaryx-hover disabled:cursor-not-allowed"
        >
          {loading ? "Processing..." : "Pay Now"}
        </button>
      )}
    </form>
  );
};

// The main Checkout Page
const CheckoutPage = () => {
  const { data, loading } = useQuery(GET_CART);

  if (loading) return <p>Loading...</p>;
  if (!data) return null;

  const cartItems: CartItem[] = data.cart || [];
  const totalPrice = computeTotal(cartItems);

  return (
    <Elements stripe={stripePromise}>
      <div className="mx-auto max-w-5xl px-4 py-8">
        <h1 className="mb-6 text-2xl font-bold text-gray-800">Checkout</h1>
        <div className="grid grid-cols-1 gap-8 md:grid-cols-2">
          {/* LEFT COLUMN: Cart Summary */}
          <div className="space-y-4 rounded-md border border-gray-200 p-4 shadow-sm">
            <h2 className="mb-2 text-lg font-semibold text-gray-800">
              Your Cart
            </h2>
            {cartItems.length < 1 ? (
              <p className="text-sm text-gray-600">No items in cart.</p>
            ) : (
              <div className="space-y-3">
                {cartItems.map((item) => (
                  <div
                    key={item.product.id}
                    className="flex items-center justify-between border-b pb-2 last:border-0"
                  >
                    <div>
                      <ImgComp
                        src={item.product.imageUrl}
                        alt={item.product.title}
                        className="w-16 h-16 object-cover rounded"
                      />{" "}
                      <p className="text-sm font-medium text-gray-700">
                        {item.product.title}
                      </p>
                      <p className="text-xs text-gray-500">
                        Quantity: {item.quantity}
                      </p>
                    </div>
                    <div>
                      <span className="text-sm font-semibold text-gray-800">
                        ${(item.product.price * item.quantity).toFixed(2)}
                      </span>
                    </div>
                  </div>
                ))}

                {/* Total Price */}
                <div className="mt-4 flex items-center justify-between border-t pt-2">
                  <span className="text-base font-semibold text-gray-800">
                    Total:
                  </span>
                  <span className="text-base font-semibold text-gray-800">
                    ${totalPrice.toFixed(2)}
                  </span>
                </div>
              </div>
            )}
          </div>

          {/* RIGHT COLUMN: Payment Form */}
          <CheckoutForm cartItems={cartItems} />
        </div>
      </div>
    </Elements>
  );
};

export default CheckoutPage;
