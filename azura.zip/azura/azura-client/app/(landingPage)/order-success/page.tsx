import React from "react";
import OrderSuccess from ".";

const page = () => {
  return <OrderSuccess />;
};

export default page;
