import React from "react";
import Orders from ".";

const page = () => {
  return <Orders />;
};

export default page;
