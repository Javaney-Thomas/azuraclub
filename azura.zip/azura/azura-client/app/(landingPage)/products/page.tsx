import React from "react";
import Products from ".";

const page = () => {
  return <Products />;
};

export default page;
