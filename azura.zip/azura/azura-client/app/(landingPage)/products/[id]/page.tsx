import React from "react";
import ProductDetails from ".";

const page = () => {
  return <ProductDetails />;
};

export default page;
