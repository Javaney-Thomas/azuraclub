import React from "react";
import SingleOrder from ".";

const page = () => {
  return <SingleOrder />;
};

export default page;
