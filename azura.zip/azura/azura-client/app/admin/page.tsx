import React from "react";
import Admin from ".";

const page = () => {
  return (
    <div>
      <Admin />
    </div>
  );
};

export default page;
