import React from "react";
import UpdateOrderStatus from ".";

const page = () => {
  return (
    <div>
      <UpdateOrderStatus />
    </div>
  );
};

export default page;
