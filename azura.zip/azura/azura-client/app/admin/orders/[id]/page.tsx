import React from "react";
import Order from ".";

const page = () => {
  return (
    <div>
      <Order />
    </div>
  );
};

export default page;
