import React from "react";
import Orders from ".";

const page = () => {
  return (
    <div>
      <Orders />
    </div>
  );
};

export default page;
