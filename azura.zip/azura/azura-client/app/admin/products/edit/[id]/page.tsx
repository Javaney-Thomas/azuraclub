import React from "react";
import UpdateProductPage from ".";

const page = () => {
  return (
    <div>
      <UpdateProductPage />
    </div>
  );
};

export default page;
