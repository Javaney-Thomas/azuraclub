import React from "react";
import CreateProductForm from ".";

const page = () => {
  return <CreateProductForm />;
};

export default page;
