import React from "react";
import SingleUserPage from ".";

const page = () => {
  return <SingleUserPage />;
};

export default page;
