import React from "react";
import Users from ".";

const page = () => {
  return (
    <div>
      <Users />
    </div>
  );
};

export default page;
