import React from "react";
import ReviewForm from ".";

const page = () => {
  return (
    <div>
      <ReviewForm />
    </div>
  );
};

export default page;
