(globalThis.TURBOPACK = globalThis.TURBOPACK || []).push([
    "static/chunks/app_(landingPage)_products_[id]_page_tsx_97fed385._.js",
    {},
]);
(globalThis.TURBOPACK_CHUNK_LISTS = globalThis.TURBOPACK_CHUNK_LISTS || []).push({
  "path": "static/chunks/app_(landingPage)_products_[id]_page_tsx_97fed385._.js",
  "chunks": [
    "static/chunks/_66cf7fd7._.js"
  ],
  "source": "dynamic"
});
