(globalThis.TURBOPACK = globalThis.TURBOPACK || []).push([
    "static/chunks/app_(landingPage)_page_tsx_0935698f._.js",
    {},
]);
(globalThis.TURBOPACK_CHUNK_LISTS = globalThis.TURBOPACK_CHUNK_LISTS || []).push({
  "path": "static/chunks/app_(landingPage)_page_tsx_0935698f._.js",
  "chunks": [
    "static/chunks/_00428ecf._.js"
  ],
  "source": "dynamic"
});
