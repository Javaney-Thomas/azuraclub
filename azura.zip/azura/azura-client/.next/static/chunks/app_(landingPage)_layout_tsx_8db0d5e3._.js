(globalThis.TURBOPACK = globalThis.TURBOPACK || []).push([
    "static/chunks/app_(landingPage)_layout_tsx_8db0d5e3._.js",
    {},
]);
(globalThis.TURBOPACK_CHUNK_LISTS = globalThis.TURBOPACK_CHUNK_LISTS || []).push({
  "path": "static/chunks/app_(landingPage)_layout_tsx_8db0d5e3._.js",
  "chunks": [
    "static/chunks/[turbopack]_browser_dev_hmr-client_hmr-client_ts_f26b21f4._.js",
    "static/chunks/_1f5549dd._.js",
    "static/chunks/node_modules_next_54b0501c._.js",
    "static/chunks/node_modules_framer-motion_dist_es_2e6f230b._.js",
    "static/chunks/node_modules_zod_lib_index_mjs_ee760afb._.js",
    "static/chunks/node_modules_8f422314._.js",
    "static/chunks/app_shared_components_Loader_loader_9eefb539.css"
  ],
  "source": "dynamic"
});
