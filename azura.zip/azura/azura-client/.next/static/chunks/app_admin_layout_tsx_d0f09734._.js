(globalThis.TURBOPACK = globalThis.TURBOPACK || []).push([
    "static/chunks/app_admin_layout_tsx_d0f09734._.js",
    {},
]);
(globalThis.TURBOPACK_CHUNK_LISTS = globalThis.TURBOPACK_CHUNK_LISTS || []).push({
  "path": "static/chunks/app_admin_layout_tsx_d0f09734._.js",
  "chunks": [
    "static/chunks/[turbopack]_browser_dev_hmr-client_hmr-client_ts_a8a1de31._.js",
    "static/chunks/node_modules_3e2a6a7c._.js",
    "static/chunks/_295b6c76._.js"
  ],
  "source": "dynamic"
});
