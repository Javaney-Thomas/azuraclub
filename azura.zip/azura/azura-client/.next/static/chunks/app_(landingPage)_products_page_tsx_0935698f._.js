(globalThis.TURBOPACK = globalThis.TURBOPACK || []).push([
    "static/chunks/app_(landingPage)_products_page_tsx_0935698f._.js",
    {},
]);
(globalThis.TURBOPACK_CHUNK_LISTS = globalThis.TURBOPACK_CHUNK_LISTS || []).push({
  "path": "static/chunks/app_(landingPage)_products_page_tsx_0935698f._.js",
  "chunks": [
    "static/chunks/app_3ad86715._.js"
  ],
  "source": "dynamic"
});
