(globalThis.TURBOPACK = globalThis.TURBOPACK || []).push([
    "static/chunks/app_(landingPage)_page_tsx_24705b15._.js",
    {},
]);
(globalThis.TURBOPACK_CHUNK_LISTS = globalThis.TURBOPACK_CHUNK_LISTS || []).push({
  "path": "static/chunks/app_(landingPage)_page_tsx_24705b15._.js",
  "chunks": [
    "static/chunks/node_modules_85a7a9d3._.js",
    "static/chunks/_ccc91e0d._.js"
  ],
  "source": "dynamic"
});
