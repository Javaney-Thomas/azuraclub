(globalThis.TURBOPACK = globalThis.TURBOPACK || []).push([
    "static/chunks/app_(landingPage)_products_page_tsx_98246785._.js",
    {},
]);
(globalThis.TURBOPACK_CHUNK_LISTS = globalThis.TURBOPACK_CHUNK_LISTS || []).push({
  "path": "static/chunks/app_(landingPage)_products_page_tsx_98246785._.js",
  "chunks": [
    "static/chunks/app_87f7c81d._.js"
  ],
  "source": "dynamic"
});
