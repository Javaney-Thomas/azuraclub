(globalThis.TURBOPACK = globalThis.TURBOPACK || []).push([
    "static/chunks/app_(landingPage)_page_tsx_d4f6f452._.js",
    {},
]);
(globalThis.TURBOPACK_CHUNK_LISTS = globalThis.TURBOPACK_CHUNK_LISTS || []).push({
  "path": "static/chunks/app_(landingPage)_page_tsx_d4f6f452._.js",
  "chunks": [
    "static/chunks/_1b8e38ac._.js"
  ],
  "source": "dynamic"
});
