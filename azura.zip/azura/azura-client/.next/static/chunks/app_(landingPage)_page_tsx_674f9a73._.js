(globalThis.TURBOPACK = globalThis.TURBOPACK || []).push([
    "static/chunks/app_(landingPage)_page_tsx_674f9a73._.js",
    {},
]);
(globalThis.TURBOPACK_CHUNK_LISTS = globalThis.TURBOPACK_CHUNK_LISTS || []).push({
  "path": "static/chunks/app_(landingPage)_page_tsx_674f9a73._.js",
  "chunks": [
    "static/chunks/node_modules_e2e1c883._.js",
    "static/chunks/components_ui_carousel_tsx_15de3642._.js"
  ],
  "source": "dynamic"
});
