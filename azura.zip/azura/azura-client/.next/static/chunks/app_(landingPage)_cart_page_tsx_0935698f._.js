(globalThis.TURBOPACK = globalThis.TURBOPACK || []).push([
    "static/chunks/app_(landingPage)_cart_page_tsx_0935698f._.js",
    {},
]);
(globalThis.TURBOPACK_CHUNK_LISTS = globalThis.TURBOPACK_CHUNK_LISTS || []).push({
  "path": "static/chunks/app_(landingPage)_cart_page_tsx_0935698f._.js",
  "chunks": [
    "static/chunks/app_(landingPage)_cart_index_tsx_8cbf4502._.js"
  ],
  "source": "dynamic"
});
