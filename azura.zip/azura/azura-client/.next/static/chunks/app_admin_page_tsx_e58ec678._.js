(globalThis.TURBOPACK = globalThis.TURBOPACK || []).push([
    "static/chunks/app_admin_page_tsx_e58ec678._.js",
    {},
]);
(globalThis.TURBOPACK_CHUNK_LISTS = globalThis.TURBOPACK_CHUNK_LISTS || []).push({
  "path": "static/chunks/app_admin_page_tsx_e58ec678._.js",
  "chunks": [
    "static/chunks/node_modules_lodash_e5c67f5b._.js",
    "static/chunks/node_modules_recharts_es6_c03c117c._.js",
    "static/chunks/node_modules_framer-motion_dist_es_2e6f230b._.js",
    "static/chunks/node_modules_17bb4ccc._.js",
    "static/chunks/app_527c2f15._.js",
    "static/chunks/app_shared_components_Loader_loader_9eefb539.css"
  ],
  "source": "dynamic"
});
